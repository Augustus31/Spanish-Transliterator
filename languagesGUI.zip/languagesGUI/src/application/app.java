package application;
	
import javafx.application.Application;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;


public class app extends Application {
	public static String language;
	@Override
	public void start(Stage primaryStage) {
		try {
			GridPane root = new GridPane();
			Scene scene = new Scene(root,550,210);
			scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
			primaryStage.setScene(scene);
			Label title = new Label(language + " Transliterator");
			title.setStyle("-fx-text-fill: black; -fx-font: normal bold 30px 'Georgia';");
			Label desc = new Label("Press Begin to start. Once started, type //k anywhere to kill the program.");
			root.setHgap(20);
			root.setVgap(20);
			root.add(title, 1, 1);
			root.add(desc, 1, 3);
			Button begin = new Button("Begin");
			begin.getStyleClass().add("button2");
			root.add(begin, 1, 5, 2, 1);
			primaryStage.show();
			//RadioButton coba = new RadioButton("Coba");
			//RadioButton buzzin = new RadioButton("Buzzin");
			//ToggleGroup buzzerApp = new ToggleGroup();
			//coba.setToggleGroup(buzzerApp);
			//buzzin.setToggleGroup(buzzerApp);
			//VBox vbox = new VBox(coba, buzzin);
			//vbox.setSpacing(20);
			primaryStage.setOnCloseRequest(new EventHandler<WindowEvent>() {
				@Override
			    public void handle(WindowEvent t) {
			        Platform.exit();
			        System.exit(0);
			    }
			});
	        EventHandler<ActionEvent> start = new EventHandler<ActionEvent>() { 
	            public void handle(ActionEvent e) 
	            { 
	            	Platform.exit();
	            } 
	        }; 
	        begin.setOnAction(start);
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args) {
		language = args[0];
		launch(args);
	}
}
