package thing;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.util.ArrayList;

import org.jnativehook.GlobalScreen;
import org.jnativehook.NativeHookException;
import org.jnativehook.keyboard.NativeKeyEvent;
import org.jnativehook.keyboard.NativeKeyListener;

import application.app;
import javafx.application.Application;
import javafx.stage.Stage;

public class Spanish implements NativeKeyListener {
	public static Robot bot;
	public static ArrayList<String> typed;
	public static boolean isCaps = false;
	public static boolean shiftHeld = false;
	public static boolean slash1 = false;
	public static boolean slash2 = false;
	public void nativeKeyPressed(NativeKeyEvent e) {
		System.out.println("Key Pressed: " + NativeKeyEvent.getKeyText(e.getKeyCode()));
		if(e.getKeyCode() != NativeKeyEvent.VC_SLASH && e.getKeyCode() != NativeKeyEvent.VC_1 && e.getKeyCode() != NativeKeyEvent.VC_2) {
			if(e.getKeyCode() == NativeKeyEvent.VC_SHIFT && !Toolkit.getDefaultToolkit().getLockingKeyState(KeyEvent.VK_CAPS_LOCK)) {
				isCaps = true;
				shiftHeld = true;
			}
			else if(Toolkit.getDefaultToolkit().getLockingKeyState(KeyEvent.VK_CAPS_LOCK) && e.getKeyCode() != NativeKeyEvent.VC_SHIFT) {
				isCaps = true;
			}
			else {
				if(!shiftHeld || (shiftHeld &&Toolkit.getDefaultToolkit().getLockingKeyState(KeyEvent.VK_CAPS_LOCK))) {
					isCaps = false;
				}
			}
		}
		System.out.println(isCaps);
		if (e.getKeyCode() == NativeKeyEvent.VC_SLASH) {
			if(slash1) {
				slash2 = true;
			}
			else {
				slash1 = true;
			}
            		/*try {
                		GlobalScreen.unregisterNativeHook();
            		} catch (NativeHookException nativeHookException) {
                		nativeHookException.printStackTrace();
            		}*/
					
        	}
		else{
			if (e.getKeyCode() == NativeKeyEvent.VC_1 && slash1 && slash2 && (typed.get(0) == "a" || typed.get(0) == "A" || typed.get(0) == "e" || typed.get(0) == "E" || typed.get(0) == "i" || typed.get(0) == "I" ||typed.get(0) == "o" || typed.get(0) == "O" || typed.get(0) == "u" || typed.get(0) == "U" || typed.get(0) == "n" || typed.get(0) == "N"|| typed.get(0) == "1" || typed.get(0) == "2")) {
				bot.keyPress(KeyEvent.VK_BACK_SPACE);
				try {
					Thread.sleep(5);
				} catch (InterruptedException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				bot.keyRelease(KeyEvent.VK_BACK_SPACE);
				try {
					Thread.sleep(5);
				} catch (InterruptedException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				bot.keyPress(KeyEvent.VK_BACK_SPACE);
				try {
					Thread.sleep(5);
				} catch (InterruptedException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				bot.keyRelease(KeyEvent.VK_BACK_SPACE);
				try {
					Thread.sleep(5);
				} catch (InterruptedException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				bot.keyPress(KeyEvent.VK_BACK_SPACE);
				try {
					Thread.sleep(5);
				} catch (InterruptedException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				bot.keyRelease(KeyEvent.VK_BACK_SPACE);
				try {
					Thread.sleep(5);
				} catch (InterruptedException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				bot.keyPress(KeyEvent.VK_BACK_SPACE);
				try {
					Thread.sleep(5);
				} catch (InterruptedException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				bot.keyRelease(KeyEvent.VK_BACK_SPACE); 
				try {
					Thread.sleep(25);
				} catch (InterruptedException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				if(typed.get(0).contentEquals("A")) {
					//System.exit(0);
					if(isCaps) {
						pressUnicode2(bot, "�");
					}
					else {
						pressUnicode(bot, 225);
					}
				}
				if(typed.get(0).contentEquals("E")) {
					//System.exit(0);
					if(isCaps) {
						pressUnicode2(bot, "�");
					}
					else {
						pressUnicode(bot, 233);
					}
				}
				if(typed.get(0).contentEquals("I")) {
					//System.exit(0);
					if(isCaps) {
						pressUnicode2(bot, "�");
					}
					else {
						pressUnicode(bot, 237);
					}
				}
				if(typed.get(0).contentEquals("O")) {
					//System.exit(0);
					if(isCaps) {
						pressUnicode2(bot, "�");
					}
					else {
						pressUnicode(bot, 243);
					}
				}
				if(typed.get(0).contentEquals("U")) {
					//System.exit(0);
					if(isCaps) {
						pressUnicode2(bot, "�");
					}
					else {
						pressUnicode(bot, 250);
					}
				}
				if(typed.get(0).contentEquals("N")) {
					//System.exit(0);
					if(isCaps) {
						pressUnicode(bot, 209);
					}
					else {
						pressUnicode2(bot, "�");
					}
				}
				if(typed.get(0).contentEquals("1")) {
					//System.exit(0);
					if(isCaps && !Toolkit.getDefaultToolkit().getLockingKeyState(KeyEvent.VK_CAPS_LOCK)) {
						pressUnicode2(bot, "�");
					}
				}
				if(typed.get(0).contentEquals("2")) {
					//System.exit(0);
					if(isCaps && !Toolkit.getDefaultToolkit().getLockingKeyState(KeyEvent.VK_CAPS_LOCK)) {
						pressUnicode2(bot, "�");
					}
				}
			}				
			else if (e.getKeyCode() == NativeKeyEvent.VC_2 && slash1 && slash2 && (typed.get(0) == "u" || typed.get(0) == "U" )) {
				bot.keyPress(KeyEvent.VK_BACK_SPACE);
				try {
					Thread.sleep(5);
				} catch (InterruptedException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				bot.keyRelease(KeyEvent.VK_BACK_SPACE);
				try {
					Thread.sleep(5);
				} catch (InterruptedException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				bot.keyPress(KeyEvent.VK_BACK_SPACE);
				try {
					Thread.sleep(5);
				} catch (InterruptedException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				bot.keyRelease(KeyEvent.VK_BACK_SPACE);
				try {
					Thread.sleep(5);
				} catch (InterruptedException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				bot.keyPress(KeyEvent.VK_BACK_SPACE);
				try {
					Thread.sleep(5);
				} catch (InterruptedException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				bot.keyRelease(KeyEvent.VK_BACK_SPACE);
				try {
					Thread.sleep(5);
				} catch (InterruptedException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				bot.keyPress(KeyEvent.VK_BACK_SPACE);
				try {
					Thread.sleep(5);
				} catch (InterruptedException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				bot.keyRelease(KeyEvent.VK_BACK_SPACE);
				try {
					Thread.sleep(25);
				} catch (InterruptedException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				if(typed.get(0).contentEquals("U")) {
					//System.exit(0);
					if(isCaps) {
						pressUnicode(bot, 220);
					}
					else {
						pressUnicode(bot, 252);
					}
				}
			}
			else if (e.getKeyCode() == NativeKeyEvent.VC_K && slash1 && slash2) {
				bot.keyPress(KeyEvent.VK_BACK_SPACE);
				bot.keyRelease(KeyEvent.VK_BACK_SPACE);
				bot.keyPress(KeyEvent.VK_BACK_SPACE);
				bot.keyRelease(KeyEvent.VK_BACK_SPACE);
				bot.keyPress(KeyEvent.VK_BACK_SPACE);
				bot.keyRelease(KeyEvent.VK_BACK_SPACE);
				System.exit(0);
			}
			else {
				slash1 = false;
				slash2 = false;
				typed.set(0, NativeKeyEvent.getKeyText(e.getKeyCode()));
				System.out.println(typed.get(0));
			}	
		}
	}

	public void nativeKeyReleased(NativeKeyEvent e) {
		System.out.println("Key Released: " + NativeKeyEvent.getKeyText(e.getKeyCode()));
		if(e.getKeyCode() == NativeKeyEvent.VC_SHIFT) {
			shiftHeld = false;
		}
	}

	public void nativeKeyTyped(NativeKeyEvent e) {
		System.out.println("Key Typed: " + e.getKeyText(e.getKeyCode()));
	}
	public static void pressUnicode(Robot r, int key_code)
	{
	    r.keyPress(KeyEvent.VK_ALT);

	    for(int i = 3; i >= 0; --i)
	    {
	        // extracts a single decade of the key-code and adds
	        // an offset to get the required VK_NUMPAD key-code
	        int numpad_kc = key_code / (int) (Math.pow(10, i)) % 10 + KeyEvent.VK_NUMPAD0;

	        r.keyPress(numpad_kc);
	        r.keyRelease(numpad_kc);
	    }

	    r.keyRelease(KeyEvent.VK_ALT);
	}
	public static void pressUnicode2(Robot r, String c) {
		// Set desired character
		StringSelection selection = new StringSelection(c);
		// Copy it to clipboard
		Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
		clipboard.setContents(selection, null);
		// Paste it
		r.keyPress(KeyEvent.VK_CONTROL);
		r.keyPress(KeyEvent.VK_V);
		r.keyRelease(KeyEvent.VK_V);
		r.keyRelease(KeyEvent.VK_CONTROL);
	}
	public static void main(String[] args){
		String[] x = new String[1];
		x[0] = "Spanish";
		app.language = "Spanish";
		Application.launch(app.class, x);
		try {
			bot = new Robot();
		} catch (AWTException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		typed = new ArrayList<String>();
		typed.add(null);
		try {
			GlobalScreen.registerNativeHook();
		}
		catch (NativeHookException ex) {
			System.err.println("There was a problem registering the native hook.");
			System.err.println(ex.getMessage());

			System.exit(1);
		}

		GlobalScreen.addNativeKeyListener(new Spanish());
		
		
	}
}

